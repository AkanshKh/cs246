USE week14;
INSERT INTO location(location_id,city,state,country) VALUES(1,'Madison','WI','USA');
INSERT INTO location(location_id,city,state,country) VALUES(2,'Fresno','CA','USA');
INSERT INTO location(location_id,city,state,country) VALUES(5,'Chennai','TN','India');
