USE week14;
INSERT INTO product(product_id,product_name,category,price) VALUES(11,'Lee Jeans','Apparel',25);
INSERT INTO product(product_id,product_name,category,price) VALUES(12,'Zord','Toys',18);
INSERT INTO product(product_id,product_name,category,price) VALUES(13,'Biro Pen','Stationery',2);
