USE week09;
INSERT INTO boats_1(bid,bname,bcolor) VALUES(101,'Interlake','blue');
INSERT INTO boats_1(bid,bname,bcolor) VALUES(102,'Interlake','red');
INSERT INTO boats_1(bid,bname,bcolor) VALUES(103,'Clipper','green');
INSERT INTO boats_1(bid,bname,bcolor) VALUES(104,'Marine','red');
