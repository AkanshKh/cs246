USE week12;
INSERT INTO boats(bid,bname,bcolor) VALUES(101,'Interlake','blue');
INSERT INTO boats(bid,bname,bcolor) VALUES(102,'Interlake','red');
INSERT INTO boats(bid,bname,bcolor) VALUES(103,'Clipper','green');
INSERT INTO boats(bid,bname,bcolor) VALUES(104,'Marine','red');
